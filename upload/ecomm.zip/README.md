# ShopMitra - Your Shopping Friend 🛍️

A production-ready e-commerce platform built with React, TypeScript, Tailwind CSS, and Neon PostgreSQL.

## ✨ Features

- **Beautiful Cursive Logo** - Custom ShopMitra branding with Dancing Script font
- **Login-Required Checkout** - Users must sign in before placing orders
- **Real Dodo Payments Integration** - Secure payment gateway (UPI, Cards, Net Banking, Wallets)
- **Neon PostgreSQL Database** - 12-table schema with full CRUD operations
- **Role-Based Authentication** - Customer, Admin, and Super Admin roles
- **Admin Dashboard** - Full product, order, banner, and customer management
- **Real Product Images** - AI-generated professional product photography
- **Shopping Cart & Wishlist** - Persistent cart with localStorage
- **Coupon System** - Dynamic discount codes
- **Responsive Design** - Mobile-first, works on all devices

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## 🔐 Demo Accounts

**Admin Access:**
- Email: `admin@shopmitra.in`
- Password: `admin123`

**Customer Access:**
- Email: `demo@shopmitra.in`
- Password: `demo123`

## 💳 Dodo Payments Setup

ShopMitra uses **Dodo Payments** for secure payment processing.

### Configuration

1. **Create Dodo Account**
   - Sign up at [dodopayments.com](https://dodopayments.com)
   - Get your API key from Developer → API Keys

2. **Set Environment Variable**
   ```bash
   DODO_PAYMENTS_API_KEY=your_api_key_here
   ```

3. **Configure Webhook** (for production)
   - Add webhook URL in Developer → Webhooks
   - Use the webhook handler in `src/services/payments.ts`

### Payment Flow

1. Customer adds items to cart
2. Must login to proceed to checkout
3. Enters shipping address
4. Selects Dodo Payments
5. Redirected to Dodo's secure checkout
6. Payment verified via webhook
7. Order confirmed and stock updated

### Test Mode

By default, ShopMitra runs in **test mode**. To enable live payments:

```typescript
// In src/services/payments.ts
export const DODO_CONFIG = {
  testMode: false, // Set to false for production
  // ...
};
```

## 🗄️ Database

### Neon PostgreSQL

The app connects to Neon PostgreSQL with automatic fallback to localStorage.

**Connection String:**
```
postgresql://neondb_owner:npg_i5px1sYZqyLu@ep-round-king-avxa8z0s-pooler.c-11.us-east-1.aws.neon.tech/neondb?sslmode=require
```

### Schema

- `users` - Authentication & roles
- `products` - Product catalog with images
- `orders` - Order management
- `order_items` - Order line items
- `categories` - Product categories
- `banners` - Homepage banners
- `coupons` - Discount codes
- `wishlists` - User wishlists
- `reviews` - Product reviews
- `addresses` - Shipping addresses
- `audit_logs` - Admin action tracking
- `product_variants` - Product options

## 🎨 Branding

- **Name:** ShopMitra (Shop + Mitra = Shopping Friend)
- **Logo:** Cursive "ShopMitra" with gradient icon
- **Colors:** Indigo/Purple gradient
- **Fonts:** Dancing Script (logo), Inter (body)
- **Tagline:** "Your Shopping Friend"

## 📱 Key Pages

- **Home** - Hero banners, featured products, categories
- **Products** - Grid view with filters and search
- **Product Detail** - Images, specs, reviews, related products
- **Cart** - Quantity management, coupons, totals
- **Checkout** - Login required, address, Dodo payment
- **Account** - Order history, profile management
- **Admin** - Dashboard, CRUD operations, analytics

## 🔒 Security Features

- Login-required checkout
- Role-based access control
- Password hashing (SHA-256)
- JWT-like token authentication
- Protected admin routes
- Secure payment verification
- Audit logging

## 🛠️ Tech Stack

- **Frontend:** React 18, TypeScript, Tailwind CSS 4
- **Database:** Neon PostgreSQL (@neondatabase/serverless)
- **Payments:** Dodo Payments API
- **Routing:** React Router v6 (HashRouter)
- **State:** Context API + useReducer
- **Icons:** Lucide React
- **Build:** Vite

## 📦 Project Structure

```
src/
├── components/
│   ├── Layout.tsx       # Header, footer, navigation
│   └── Logo.tsx         # ShopMitra logo component
├── pages/
│   ├── Home.tsx         # Homepage with banners
│   ├── Products.tsx     # Product listing
│   ├── ProductDetail.tsx # Single product
│   ├── Cart.tsx         # Shopping cart
│   ├── Checkout.tsx     # Login-required checkout
│   ├── Auth.tsx         # Login/Register
│   ├── Account.tsx      # User dashboard
│   ├── Admin.tsx        # Admin panel
│   ├── PaymentReturn.tsx # Dodo payment handler
│   └── StaticPages.tsx  # About, Contact, FAQ, etc.
├── store/
│   └── AppContext.tsx   # Global state management
├── db/
│   ├── connection.ts    # Neon DB connection
│   ├── manager.ts       # DB operations + localStorage fallback
│   └── seed.ts          # Demo data seeder
├── services/
│   ├── auth.ts          # Authentication service
│   ├── products.ts      # Product CRUD
│   ├── orders.ts        # Order management
│   ├── banners.ts       # Banner management
│   └── payments.ts      # Dodo Payments integration
└── App.tsx              # Main app with routing
```

## 🌐 Deployment

### Production Checklist

- [ ] Set `DODO_PAYMENTS_API_KEY` environment variable
- [ ] Configure Dodo webhook URL
- [ ] Set `DODO_CONFIG.testMode = false`
- [ ] Update database connection string
- [ ] Configure CORS for API endpoints
- [ ] Enable HTTPS
- [ ] Set up email notifications
- [ ] Configure CDN for images
- [ ] Set up monitoring and logging

### Environment Variables

```bash
# Database
DATABASE_URL=postgresql://...

# Dodo Payments
DODO_PAYMENTS_API_KEY=your_key
DODO_PAYMENTS_WEBHOOK_KEY=your_webhook_secret

# App
NODE_ENV=production
VITE_APP_URL=https://shopmitra.in
```

## 📝 License

MIT License - Feel free to use for your projects!

## 🤝 Support

For questions or issues:
- Email: support@shopmitra.in
- Docs: [dodopayments.com/docs](https://docs.dodopayments.com)

---

**Built with ❤️ by ShopMitra Team**
