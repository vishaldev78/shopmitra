# 🛍️ ShopMitra - Complete Fullstack E-Commerce Platform

## 📋 Table of Contents
1. [System Architecture](#system-architecture)
2. [Technology Stack](#technology-stack)
3. [Database Design](#database-design)
4. [API Documentation](#api-documentation)
5. [Authentication Flow](#authentication-flow)
6. [Payment Integration](#payment-integration)
7. [Caching Strategy](#caching-strategy)
8. [File Upload System](#file-upload-system)
9. [Email Notifications](#email-notifications)
10. [Testing Strategy](#testing-strategy)
11. [Deployment Guide](#deployment-guide)
12. [Security Measures](#security-measures)

---

## 🏗️ System Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                         CLIENT LAYER                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   React SPA  │  │  Mobile App  │  │  Admin Panel │      │
│  │  (Vite+TS)   │  │  (Optional)  │  │  (Optional)  │      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │
└─────────┼──────────────────┼──────────────────┼─────────────┘
          │                  │                  │
          └──────────────────┼──────────────────┘
                             │ HTTPS
                             ▼
┌─────────────────────────────────────────────────────────────┐
│                      API GATEWAY LAYER                       │
│  ┌──────────────────────────────────────────────────────┐  │
│  │              Node.js + Express + TypeScript           │  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐          │  │
│  │  │   Auth   │  │  Routes  │  │Middleware│          │  │
│  │  │  (JWT)   │  │Handlers  │  │ (CORS,  │          │  │
│  │  │          │  │          │  │  Helmet)  │          │  │
│  │  └──────────┘  └──────────┘  └──────────┘          │  │
│  └──────────────────────────────────────────────────────┘  │
└────────────────────────┬────────────────────────────────────┘
                         │
          ┌──────────────┼──────────────┐
          │              │              │
          ▼              ▼              ▼
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│  Service    │  │  Service    │  │  Service    │
│   Layer     │  │   Layer     │  │   Layer     │
│ ┌─────────┐ │  │ ┌─────────┐ │  │ ┌─────────┐ │
│ │ Product │ │  │ │  Order  │ │  │ │ Payment │ │
│ │ Service │ │  │ │ Service │ │  │ │ Service │ │
│ └─────────┘ │  │ └─────────┘ │  │ └─────────┘ │
│ ┌─────────┐ │  │ ┌─────────┐ │  │ ┌─────────┐ │
│ │  Auth   │ │  │ │  Email  │ │  │ │  Cache  │ │
│ │ Service │ │  │ │ Service │ │  │ │ (Redis) │ │
│ └─────────┘ │  │ └─────────┘ │  │ └─────────┘ │
└──────┬──────┘  └──────┬──────┘  └──────┬──────┘
       │                │                │
       └────────────────┼────────────────┘
                        │
          ┌─────────────┼─────────────┐
          │             │             │
          ▼             ▼             ▼
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│   Neon       │ │    Redis     │ │  Cloudinary  │
│ PostgreSQL   │ │   (Upstash)  │ │  (File Store)│
│              │ │              │ │              │
│ • Users      │ │ • Sessions   │ │ • Product    │
│ • Products   │ │ • Cache      │ │   Images     │
│ • Orders     │ │ • Rate Limit │ │ • Banners    │
│ • Payments   │ │              │ │ • Avatars    │
└──────────────┘ └──────────────┘ └──────────────┘
```

### Data Flow

```
1. User Request Flow:
   Client → API Gateway → Auth Middleware → Route Handler → 
   Service Layer → Database → Response → Client

2. Payment Flow:
   Client → Create Order → Dodo Checkout → Payment Success → 
   Webhook → Update Order → Email Notification → Client

3. File Upload Flow:
   Client → Upload Request → Multer → Cloudinary → 
   Store URL in DB → Return URL to Client
```

---

## 🛠️ Technology Stack

### Backend
- **Runtime**: Node.js 20+ with TypeScript 5.3
- **Framework**: Express.js 4.18
- **Database**: Neon PostgreSQL (Serverless)
- **Cache**: Redis (Upstash)
- **Authentication**: JWT (jsonwebtoken)
- **Validation**: Zod
- **File Upload**: Multer + Cloudinary
- **Email**: Nodemailer
- **Payments**: Dodo Payments SDK
- **Security**: Helmet, CORS, express-rate-limit

### Frontend
- **Framework**: React 18.2
- **Build Tool**: Vite 6.3
- **Styling**: Tailwind CSS 4.1
- **Routing**: React Router DOM 6.8
- **State**: Context API + useReducer
- **HTTP Client**: Fetch API / Axios

### Development Tools
- **Testing**: Jest + Supertest
- **Linting**: ESLint + Prettier
- **Type Checking**: TypeScript
- **Hot Reload**: tsx (development)

### Deployment
- **Backend**: Railway / Render / AWS EC2
- **Frontend**: Vercel / Netlify
- **Database**: Neon (Managed PostgreSQL)
- **Cache**: Upstash (Managed Redis)
- **File Storage**: Cloudinary
- **Email**: SendGrid / AWS SES

---

## 🗄️ Database Design

### Entity Relationship Diagram

```
┌─────────────┐
│   users     │
├─────────────┤
│ id (PK)     │
│ email       │◄───────┐
│ password    │        │
│ name        │        │
│ role        │        │
│ is_active   │        │
└─────────────┘        │
                       │
                       │ 1:N
                       │
┌─────────────┐        │       ┌─────────────┐
│  orders     │────────┘       │order_items  │
├─────────────┤ 1:N           ├─────────────┤
│ id (PK)     │──────────────►│ id (PK)     │
│ order_num   │               │ order_id(FK)│
│ user_id(FK) │               │ product_id  │
│ total       │               │ quantity    │
│ status      │               │ unit_price  │
│ payment     │               └─────────────┘
└─────────────┘
        │
        │ N:1
        ▼
┌─────────────┐       ┌─────────────┐
│  products   │       │ categories  │
├─────────────┤       ├─────────────┤
│ id (PK)     │◄──────│ id (PK)     │
│ name        │ N:1   │ name        │
│ price       │       │ slug        │
│ stock       │       │ parent_id   │
│ category_id │──────►└─────────────┘
│ images[]    │
└─────────────┘
```

### Table Schemas

#### 1. Users Table
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  role VARCHAR(50) DEFAULT 'customer' 
    CHECK (role IN ('customer', 'admin', 'super_admin')),
  avatar_url TEXT,
  phone VARCHAR(20),
  is_active BOOLEAN DEFAULT true,
  email_verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
```

#### 2. Products Table
```sql
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(255) UNIQUE NOT NULL,
  description TEXT,
  short_description TEXT,
  price DECIMAL(10,2) NOT NULL,
  compare_price DECIMAL(10,2),
  images TEXT[] DEFAULT '{}',
  category_id UUID REFERENCES categories(id),
  brand VARCHAR(255),
  sku VARCHAR(100) UNIQUE,
  stock INTEGER DEFAULT 0,
  rating DECIMAL(2,1) DEFAULT 0,
  review_count INTEGER DEFAULT 0,
  is_featured BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  tags TEXT[] DEFAULT '{}',
  specifications JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_slug ON products(slug);
CREATE INDEX idx_products_brand ON products(brand);
CREATE INDEX idx_products_tags ON products USING GIN(tags);
```

#### 3. Orders Table
```sql
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number VARCHAR(50) UNIQUE NOT NULL,
  user_id UUID REFERENCES users(id),
  guest_email VARCHAR(255),
  subtotal DECIMAL(10,2) NOT NULL,
  discount DECIMAL(10,2) DEFAULT 0,
  shipping DECIMAL(10,2) DEFAULT 0,
  tax DECIMAL(10,2) DEFAULT 0,
  total DECIMAL(10,2) NOT NULL,
  status VARCHAR(50) DEFAULT 'pending' 
    CHECK (status IN ('pending', 'confirmed', 'processing', 
                      'shipped', 'delivered', 'cancelled')),
  payment_status VARCHAR(50) DEFAULT 'pending'
    CHECK (payment_status IN ('pending', 'paid', 'failed', 'refunded')),
  payment_method VARCHAR(50),
  payment_id VARCHAR(255),
  shipping_address JSONB NOT NULL,
  billing_address JSONB,
  tracking_number VARCHAR(100),
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_payment ON orders(payment_status);
CREATE INDEX idx_orders_created ON orders(created_at DESC);
```

#### 4. Order Items Table
```sql
CREATE TABLE order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES products(id),
  product_name VARCHAR(255) NOT NULL,
  product_image TEXT,
  variant_name VARCHAR(255),
  variant_value VARCHAR(255),
  quantity INTEGER NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  total_price DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_order_items_order ON order_items(order_id);
```

---

## 📡 API Documentation

### Base URL
```
Development: http://localhost:5000/api
Production: https://api.shopmitra.in/api
```

### Authentication Endpoints

#### 1. Register
```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePass123",
  "name": "John Doe"
}

Response 201:
{
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "name": "John Doe",
    "role": "customer"
  },
  "token": "jwt_token",
  "refreshToken": "refresh_token"
}
```

#### 2. Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "SecurePass123"
}

Response 200:
{
  "user": { ... },
  "token": "jwt_token",
  "refreshToken": "refresh_token"
}
```

#### 3. Refresh Token
```http
POST /api/auth/refresh
Content-Type: application/json

{
  "refreshToken": "refresh_token"
}

Response 200:
{
  "token": "new_jwt_token",
  "refreshToken": "new_refresh_token"
}
```

### Product Endpoints

#### 1. Get All Products
```http
GET /api/products?page=1&limit=20&category=electronics&search=iphone&sort=price_asc

Response 200:
{
  "products": [ ... ],
  "total": 100,
  "page": 1,
  "limit": 20,
  "totalPages": 5
}
```

#### 2. Get Single Product
```http
GET /api/products/:slug

Response 200:
{
  "id": "uuid",
  "name": "iPhone 15 Pro",
  "slug": "iphone-15-pro",
  "price": 134900,
  "images": ["url1", "url2"],
  ...
}
```

#### 3. Create Product (Admin)
```http
POST /api/products
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "name": "New Product",
  "price": 9999,
  "category_id": "uuid",
  "images": ["url1", "url2"],
  "stock": 100
}

Response 201:
{
  "product": { ... }
}
```

#### 4. Update Product (Admin)
```http
PUT /api/products/:id
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "price": 8999,
  "stock": 50
}

Response 200:
{
  "product": { ... }
}
```

#### 5. Delete Product (Admin)
```http
DELETE /api/products/:id
Authorization: Bearer <admin_token>

Response 204: No Content
```

### Order Endpoints

#### 1. Create Order
```http
POST /api/orders
Authorization: Bearer <token>
Content-Type: application/json

{
  "items": [
    {
      "product_id": "uuid",
      "quantity": 2,
      "variant_id": "uuid"
    }
  ],
  "shipping_address": {
    "fullName": "John Doe",
    "phone": "9876543210",
    "addressLine1": "123 Main St",
    "city": "Mumbai",
    "state": "Maharashtra",
    "postalCode": "400001",
    "country": "India"
  },
  "payment_method": "dodo",
  "coupon_code": "SAVE10"
}

Response 201:
{
  "order": {
    "id": "uuid",
    "order_number": "SM-ABC123",
    "total": 19998,
    "payment_url": "https://checkout.dodopayments.com/..."
  }
}
```

#### 2. Get User Orders
```http
GET /api/orders/my-orders
Authorization: Bearer <token>

Response 200:
{
  "orders": [ ... ]
}
```

#### 3. Get Order Details
```http
GET /api/orders/:id
Authorization: Bearer <token>

Response 200:
{
  "order": { ... },
  "items": [ ... ]
}
```

#### 4. Cancel Order
```http
POST /api/orders/:id/cancel
Authorization: Bearer <token>

Response 200:
{
  "message": "Order cancelled successfully",
  "refund_status": "processing"
}
```

### Admin Endpoints

#### 1. Get All Orders
```http
GET /api/admin/orders?status=pending&page=1
Authorization: Bearer <admin_token>

Response 200:
{
  "orders": [ ... ],
  "total": 500,
  "page": 1
}
```

#### 2. Update Order Status
```http
PUT /api/admin/orders/:id/status
Authorization: Bearer <admin_token>
Content-Type: application/json

{
  "status": "shipped",
  "tracking_number": "TRACK123456"
}

Response 200:
{
  "order": { ... }
}
```

#### 3. Get Dashboard Stats
```http
GET /api/admin/dashboard
Authorization: Bearer <admin_token>

Response 200:
{
  "totalRevenue": 5000000,
  "totalOrders": 1250,
  "totalCustomers": 890,
  "totalProducts": 150,
  "pendingOrders": 25,
  "lowStockProducts": 10,
  "recentOrders": [ ... ],
  "topSellingProducts": [ ... ]
}
```

### Payment Webhook

#### Dodo Payments Webhook
```http
POST /api/webhooks/dodo
Content-Type: application/json
Webhook-Signature: <signature>

{
  "event": "payment.success",
  "data": {
    "payment_id": "pay_123",
    "order_id": "order_456",
    "amount": 19998,
    "currency": "INR",
    "status": "success"
  }
}

Response 200:
{
  "received": true
}
```

---

## 🔐 Authentication Flow

### JWT Token Structure

```typescript
// Access Token Payload
{
  "userId": "uuid",
  "email": "user@example.com",
  "role": "customer",
  "iat": 1234567890,
  "exp": 1234567890  // 7 days
}

// Refresh Token Payload
{
  "userId": "uuid",
  "tokenType": "refresh",
  "iat": 1234567890,
  "exp": 1234567890  // 30 days
}
```

### Authentication Middleware

```typescript
// middleware/auth.ts
export async function authenticate(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await db`SELECT * FROM users WHERE id = ${decoded.userId}`;
    
    if (!user || !user.is_active) {
      return res.status(401).json({ error: 'User not found or inactive' });
    }

    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

// Authorization middleware
export function authorize(...roles: string[]) {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
}
```

### Password Hashing

```typescript
// services/auth.service.ts
import bcrypt from 'bcryptjs';

export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10);
  return bcrypt.hash(password, salt);
}

export async function verifyPassword(
  password: string, 
  hash: string
): Promise<boolean> {
  return bcrypt.compare(password, hash);
}
```

---

## 💳 Payment Integration

### Dodo Payments Flow

```
1. Create Order (Backend)
   └─> Validate cart & stock
   └─> Calculate totals
   └─> Create order in DB (status: pending)
   └─> Create Dodo checkout session
   └─> Return checkout URL to client

2. Redirect to Payment (Frontend)
   └─> window.location.href = checkout_url

3. Payment Processing (Dodo)
   └─> Customer enters payment details
   └─> Dodo processes payment
   └─> Dodo sends webhook to backend

4. Webhook Handler (Backend)
   └─> Verify webhook signature
   └─> Update order status (paid/failed)
   └─> Update inventory
   └─> Send email notification

5. Return to Merchant (Frontend)
   └─> Redirect to success/failure page
   └─> Show order confirmation
```

### Implementation

```typescript
// services/payment.service.ts
import DodoPayments from 'dodopayments';
import env from '../config/env';

const dodo = new DodoPayments({
  bearerToken: env.DODO_PAYMENTS_API_KEY,
  environment: env.DODO_TEST_MODE ? 'test_mode' : 'live_mode',
});

export async function createCheckoutSession(order: Order) {
  const session = await dodo.checkoutSessions.create({
    product {
      name: `Order ${order.order_number}`,
      amount: Math.round(order.total * 生100), // Convert to paise
      quantity: 1,
    }],
    customer: {
      email: order.user?.email || order.guest_email,
      name: order.shipping_address.fullName,
    },
    return_url: `${env.FRONTEND_URL}/order-success/${order.order_number}`,
    cancel_url: `${env.FRONTEND_URL}/order-cancelled/${order.order_number}`,
    meta {
      orderId: order.id,
      orderNumber: order.order_number,
    },
  });

  return session.checkout_url;
}

export async function verifyWebhookSignature(
  payload: string,
  signature: string
): Promise<boolean> {
  const crypto = require('crypto');
  const expectedSignature = crypto
    .createHmac('sha256', env.DODO_PAYMENTS_WEBHOOK_SECRET)
    .update(payload)
    .digest('hex');
  
  return signature === expectedSignature;
}
```

### Webhook Handler

```typescript
// routes/webhook.routes.ts
import { Webhook } from 'standardwebhooks';

router.post('/dodo', async (req, res) => {
  const webhook = new Webhook(env.DODO_PAYMENTS_WEBHOOK_SECRET);
  
  try {
    await webhook.verify(req.rawBody, {
      'webhook-id': req.headers['webhook-id'],
      'webhook-signature': req.headers['webhook-signature'],
      'webhook-timestamp': req.headers['webhook-timestamp'],
    });
  } catch {
    return res.status(400).json({ error: 'Invalid signature' });
  }

  const { event, data } = req.body;

  if (event === 'payment.success') {
    // Update order status
    await db`
      UPDATE orders 
      SET payment_status = 'paid', 
          payment_id = ${data.payment_id},
          status = 'confirmed'
      WHERE id = ${data.metadata.orderId}
    `;

    // Update inventory
    const orderItems = await db`
      SELECT * FROM order_items WHERE order_id = ${data.metadata.orderId}
    `;

    for (const item of orderItems) {
      await db`
        UPDATE products 
        SET stock = stock - ${item.quantity}
        WHERE id = ${item.product_id}
      `;
    }

    // Send confirmation email
    await emailService.sendOrderConfirmation(data.metadata.orderId);
  }

  res.json({ received: true });
});
```

---

## 🚀 Caching Strategy

### Redis Cache Implementation

```typescript
// config/redis.ts
import { Redis } from '@upstash/redis';

const redis = new Redis({
  url: env.REDIS_URL,
  token: env.REDIS_TOKEN,
});

export const cache = {
  // Get cached data
  async get<T>(key: string): Promise<T | null> {
    const data = await redis.get<T>(key);
    return data;
  },

  // Set cache with TTL
  async set<T>(key: string, value: T, ttlSeconds: number = 3600): Promise<void> {
    await redis.set(key, value, { ex: ttlSeconds });
  },

  // Delete cache
  async del(key: string): Promise<void> {
    await redis.del(key);
  },

  // Delete pattern
  async delPattern(pattern: string): Promise<void> {
    const keys = await redis.keys(pattern);
    if (keys.length > 0) {
      await redis.del(...keys);
    }
  },
};
```

### Cache Keys Strategy

```typescript
// Cache keys
export const CACHE_KEYS = {
  PRODUCTS: {
    LIST: 'products:list',
    FEATURED: 'products:featured',
    DETAIL: (slug: string) => `products:detail:${slug}`,
    CATEGORY: (categoryId: string) => `products:category:${categoryId}`,
  },
  CATEGORIES: 'categories:all',
  BANNERS: 'banners:active',
  USER: {
    PROFILE: (userId: string) => `user:${userId}:profile`,
    ORDERS: (userId: string) => `user:${userId}:orders`,
  },
  CART: (userId: string) => `cart:${userId}`,
};
```

### Cache Invalidation

```typescript
// services/product.service.ts
export async function updateProduct(id: string, data: UpdateProductDto) {
  // Update database
  const product = await db`UPDATE products SET ... WHERE id = ${id} RETURNING *`;

  // Invalidate cache
  await cache.del(CACHE_KEYS.PRODUCTS.DETAIL(product.slug));
  await cache.del(CACHE_KEYS.PRODUCTS.LIST);
  await cache.del(CACHE_KEYS.PRODUCTS.FEATURED);
  if (product.category_id) {
    await cache.del(CACHE_KEYS.PRODUCTS.CATEGORY(product.category_id));
  }

  return product;
}
```

### Cache-Aside Pattern

```typescript
// controllers/product.controller.ts
export async function getProducts(req, res) {
  const cacheKey = CACHE_KEYS.PRODUCTS.LIST + ':' + JSON.stringify(req.query);
  
  // Try cache first
  const cached = await cache.get(cacheKey);
  if (cached) {
    return res.json(cached);
  }

  // Fetch from database
  const products = await productService.getAll(req.query);

  // Cache for 1 hour
  await cache.set(cacheKey, products, 3600);

  res.json(products);
}
```

---

## 📤 File Upload System

### Cloudinary Configuration

```typescript
// config/cloudinary.ts
import { v2 as cloudinary } from 'cloudinary';
import env from '../config/env';

cloudinary.config({
  cloud_name: env.CLOUDINARY_CLOUD_NAME,
  api_key: env.CLOUDINARY_API_KEY,
  api_secret: env.CLOUDINARY_API_SECRET,
});

export default cloudinary;
```

### Multer Configuration

```typescript
// middleware/upload.ts
import multer from 'multer';
import env from '../config/env';

const storage = multer.memoryStorage();

export const upload = multer({
  storage,
  limits: {
    fileSize: env.MAX_FILE_SIZE, // 5MB
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = env.ALLOWED_FILE_TYPES.split(',');
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  },
});
```

### Upload Service

```typescript
// services/upload.service.ts
import cloudinary from '../config/cloudinary';

export async function uploadImage(
  file: Express.Multer.File,
  folder: string = 'products'
): Promise<string> {
  return new Promise((resolve, reject) => {
    const uploadStream = cloudinary.uploader.upload_stream(
      {
        folder: `shopmitra/${folder}`,
        transformation: [
          { quality: 'auto', fetch_format: 'auto' },
        ],
      },
      (error, result) => {
        if (error) reject(error);
        else resolve(result!.secure_url);
      }
    );

    uploadStream.end(file.buffer);
  });
}

export async function deleteImage(url: string): Promise<void> {
  const publicId = url.split('/').pop()?.split('.')[0];
  if (publicId) {
    await cloudinary.uploader.destroy(`shopmitra/${publicId}`);
  }
}
```

### Upload Controller

```typescript
// controllers/upload.controller.ts
export async function uploadProductImage(req, res) {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  try {
    const url = await uploadService.uploadImage(req.file, 'products');
    res.json({ url });
  } catch (error) {
    res.status(500).json({ error: 'Upload failed' });
  }
}
```

---

## 📧 Email Notifications

### Nodemailer Configuration

```typescript
// config/email.ts
import nodemailer from 'nodemailer';
import env from '../config/env';

export const transporter = nodemailer.createTransport({
  host: env.SMTP_HOST,
  port: env.SMTP_PORT,
  secure: env.SMTP_SECURE,
  auth: {
    user: env.SMTP_USER,
    pass: env.SMTP_PASS,
  },
});
```

### Email Templates

```typescript
// services/email.service.ts
export class EmailService {
  async sendOrderConfirmation(orderId: string) {
    const order = await db`SELECT * FROM orders WHERE id = ${orderId}`;
    const user = await db`SELECT * FROM users WHERE id = ${order.user_id}`;

    await transporter.sendMail({
      from: `"${env.EMAIL_FROM_NAME}" <${env.EMAIL_FROM}>`,
      to: user.email,
      subject: `Order Confirmation - ${order.order_number}`,
      html: `
        <h1>Thank you for your order!</h1>
        <p>Order Number: <strong>${order.order_number}</strong></p>
        <p>Total: <strong>₹${order.total}</strong></p>
        <p>We'll notify you when your order ships.</p>
      `,
    });
  }

  async sendOrderShipped(orderId: string, trackingNumber: string) {
    // Similar implementation
  }

  async sendPasswordReset(email: string, resetToken: string) {
    const resetUrl = `${env.FRONTEND_URL}/reset-password?token=${resetToken}`;
    
    await transporter.sendMail({
      from: `"${env.EMAIL_FROM_NAME}" <${env.EMAIL_FROM}>`,
      to: email,
      subject: 'Password Reset Request',
      html: `
        <h1>Password Reset</h1>
        <p>Click the link below to reset your password:</p>
        <a href="${resetUrl}">Reset Password</a>
        <p>This link expires in 1 hour.</p>
      `,
    });
  }
}
```

---

## 🧪 Testing Strategy

### Unit Tests

```typescript
// tests/services/auth.service.test.ts
import { hashPassword, verifyPassword } from '../../src/services/auth.service';

describe('Auth Service', () => {
  describe('hashPassword', () => {
    it('should hash password', async () => {
      const password = 'test123';
      const hash = await hashPassword(password);
      
      expect(hash).toBeDefined();
      expect(hash).not.toBe(password);
      expect(hash.length).toBeGreaterThan(0);
    });
  });

  describe('verifyPassword', () => {
    it('should verify correct password', async () => {
      const password = 'test123';
      const hash = await hashPassword(password);
      
      const isValid = await verifyPassword(password, hash);
      expect(isValid).toBe(true);
    });

    it('should reject incorrect password', async () => {
      const password = 'test123';
      const hash = await hashPassword(password);
      
      const isValid = await verifyPassword('wrong', hash);
      expect(isValid).toBe(false);
    });
  });
});
```

### Integration Tests

```typescript
// tests/api/auth.test.ts
import request from 'supertest';
import app from '../../src/server';

describe('Auth API', () => {
  describe('POST /api/auth/register', () => {
    it('should register new user', async () => {
      const res = await request(app)
        .post('/api/auth/register')
        .send({
          email: 'test@example.com',
          password: 'Test123!',
          name: 'Test User',
        });

      expect(res.status).toBe(201);
      expect(res.body.user).toBeDefined();
      expect(res.body.token).toBeDefined();
    });

    it('should not register duplicate email', async () => {
      await request(app)
        .post('/api/auth/register')
        .send({
          email: 'duplicate@example.com',
          password: 'Test123!',
          name: 'Test User',
        });

      const res = await request(app)
        .post('/api/auth/register')
        .send({
          email: 'duplicate@example.com',
          password: 'Test123!',
          name: 'Test User 2',
        });

      expect(res.status).toBe(400);
      expect(res.body.error).toContain('already exists');
    });
  });
});
```

### E2E Tests

```typescript
// tests/e2e/order.test.ts
describe('Order Flow', () => {
  it('should complete full order process', async () => {
    // 1. Register user
    const { token } = await registerUser();

    // 2. Add product to cart
    await addToCart(token, productId, 2);

    // 3. Create order
    const order = await createOrder(token, {
      items: [{ productId, quantity: 2 }],
      shippingAddress: mockAddress,
    });

    expect(order.status).toBe('pending');
    expect(order.payment_status).toBe('pending');

    // 4. Simulate payment webhook
    await simulatePaymentWebhook(order.id, 'success');

    // 5. Verify order updated
    const updatedOrder = await getOrder(order.id);
    expect(updatedOrder.payment_status).toBe('paid');
    expect(updatedOrder.status).toBe('confirmed');
  });
});
```

---

## 🚢 Deployment Guide

### Backend Deployment (Railway)

1. **Create Railway Project**
   ```bash
   railway init
   railway add
   ```

2. **Set Environment Variables**
   ```bash
   railway variables set NODE_ENV=production
   railway variables set DATABASE_URL=...
   railway variables set JWT_SECRET=...
   ```

3. **Deploy**
   ```bash
   railway up
   ```

### Frontend Deployment (Vercel)

1. **Connect Repository**
   - Go to vercel.com
   - Import GitHub repository
   - Select frontend folder

2. **Set Environment Variables**
   ```
   VITE_API_URL=https://api.shopmitra.in
   ```

3. **Deploy**
   - Automatic deployment on push

### Database (Neon)

1. **Create Project**
   - Go to neon.tech
   - Create new project
   - Get connection string

2. **Run Migrations**
   ```bash
   npm run db:migrate
   npm run db:seed
   ```

### Redis (Upstash)

1. **Create Database**
   - Go to upstash.com
   - Create Redis database
   - Get connection details

2. **Set Environment Variables**
   ```bash
   REDIS_URL=...
   REDIS_TOKEN=...
   ```

---

## 🔒 Security Measures

### 1. Input Validation
```typescript
import { z } from 'zod';

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8).max(100),
  name: z.string().min(2).max(100),
});

export function validate(schema: z.ZodSchema) {
  return (req, res, next) => {
    try {
      schema.parse(req.body);
      next();
    } catch (error) {
      res.status(400).json({ error: 'Validation failed', details: error.errors });
    }
  };
}
```

### 2. SQL Injection Prevention
```typescript
// ✅ Safe - Parameterized queries
const user = await db`SELECT * FROM users WHERE email = ${email}`;

// ❌ Unsafe - String concatenation
const user = await db.unsafe(`SELECT * FROM users WHERE email = '${email}'`);
```

### 3. XSS Prevention
```typescript
// Frontend - React automatically escapes
<div>{userInput}</div> // Safe

// Backend - Sanitize HTML
import sanitizeHtml from 'sanitize-html';
const clean = sanitizeHtml(dirtyHtml);
```

### 4. CSRF Protection
```typescript
// Using Helmet
app.use(helmet());

// CORS configuration
app.use(cors({
  origin: env.FRONTEND_URL,
  credentials: true,
}));
```

### 5. Rate Limiting
```typescript
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: 'Too many requests',
});

app.use('/api/', limiter);
```

### 6. Password Security
```typescript
// Hash with bcrypt (10 rounds)
const hash = await bcrypt.hash(password, 10);

// Never log passwords
console.log(user); // ❌ Contains password_hash
console.log({ ...user, password_hash: undefined }); // ✅
```

### 7. JWT Security
```typescript
// Short-lived access tokens
const token = jwt.sign(payload, secret, { expiresIn: '7d' });

// Refresh token rotation
const newRefreshToken = generateRefreshToken();
await storeRefreshToken(userId, newRefreshToken);
```

### 8. File Upload Security
```typescript
// Validate file type
const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
if (!allowedTypes.includes(file.mimetype)) {
  throw new Error('Invalid file type');
}

// Limit file size
const maxSize = 5 * 1024 * 1024; // 5MB
if (file.size > maxSize) {
  throw new Error('File too large');
}
```

---

## 📊 Performance Optimization

### 1. Database Query Optimization
```typescript
// ✅ Use indexes
CREATE INDEX idx_products_category ON products(category_id);

// ✅ Select only needed columns
const products = await db`SELECT id, name, price FROM products`;

// ❌ Don't select all columns
const products = await db`SELECT * FROM products`;
```

### 2. Pagination
```typescript
export async function getProducts(page: number = 1, limit: number = 20) {
  const offset = (page - 1) * limit;
  
  const products = await db`
    SELECT * FROM products 
    ORDER BY created_at DESC 
    LIMIT ${limit} OFFSET ${offset}
  `;

  const total = await db`SELECT COUNT(*) FROM products`;

  return {
    products,
    total: total[0].count,
    page,
    limit,
    totalPages: Math.ceil(total[0].count / limit),
  };
}
```

### 3. Caching
```typescript
// Cache expensive queries
const cachedProducts = await cache.get('products:featured');
if (cachedProducts) {
  return cachedProducts;
}

const products = await db`SELECT * FROM products WHERE is_featured = true`;
await cache.set('products:featured', products, 3600); // 1 hour
```

### 4. Compression
```typescript
import compression from 'compression';
app.use(compression());
```

---

## 📝 Environment Variables

### Required Variables

```bash
# Server
NODE_ENV=production
PORT=5000
API_URL=https://api.shopmitra.in
FRONTEND_URL=https://shopmitra.in

# Database
DATABASE_URL=postgresql://...

# Redis
REDIS_URL=https://...
REDIS_TOKEN=...

# JWT
JWT_SECRET=your_32_char_secret_here
JWT_REFRESH_SECRET=your_32_char_secret_here

# Dodo Payments
DODO_PAYMENTS_API_KEY=...
DODO_PAYMENTS_WEBHOOK_SECRET=...
DODO_TEST_MODE=false

# Cloudinary
CLOUDINARY_CLOUD_NAME=...
CLOUDINARY_API_KEY=...
CLOUDINARY_API_SECRET=...

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password
EMAIL_FROM=noreply@shopmitra.in
```

---

## 🎯 Next Steps

1. **Setup Development Environment**
   ```bash
   cd backend
   npm install
   cp .env.example .env
   # Edit .env with your credentials
   npm run db:migrate
   npm run db:seed
   npm run dev
   ```

2. **Update Frontend**
   - Replace localStorage API calls with actual API calls
   - Add axios/fetch interceptors for auth tokens
   - Implement token refresh logic

3. **Testing**
   ```bash
   npm test
   npm run test:coverage
   ```

4. **Deployment**
   - Deploy backend to Railway/Render
   - Deploy frontend to Vercel
   - Configure custom domains
   - Setup SSL certificates

5. **Monitoring**
   - Add logging (Winston/Pino)
   - Setup error tracking (Sentry)
   - Monitor performance (New Relic)

---

## 📞 Support

For questions or issues:
- Email: support@shopmitra.in
- Documentation: https://docs.shopmitra.in

---

**Built with ❤️ by ShopMitra Team**
