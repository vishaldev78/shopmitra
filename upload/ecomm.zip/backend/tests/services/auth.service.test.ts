import bcrypt from 'bcryptjs';

describe('Auth Service - Password Hashing', () => {
  it('should hash password correctly', async () => {
    const password = 'TestPassword123!';
    const hash = await bcrypt.hash(password, 10);
    
    expect(hash).toBeDefined();
    expect(hash).not.toBe(password);
    expect(hash.length).toBeGreaterThan(0);
  });

  it('should verify correct password', async () => {
    const password = 'TestPassword123!';
    const hash = await bcrypt.hash(password, 10);
    
    const isValid = await bcrypt.compare(password, hash);
    expect(isValid).toBe(true);
  });

  it('should reject incorrect password', async () => {
    const password = 'TestPassword123!';
    const hash = await bcrypt.hash(password, 10);
    
    const isValid = await bcrypt.compare('WrongPassword', hash);
    expect(isValid).toBe(false);
  });
});

describe('Auth Service - Token Generation', () => {
  it('should generate JWT token', () => {
    const jwt = require('jsonwebtoken');
    const payload = { userId: 'test-id', email: 'test@example.com' };
    const secret = 'test-secret-key-min-32-characters-long';
    
    const token = jwt.sign(payload, secret, { expiresIn: '1h' });
    
    expect(token).toBeDefined();
    expect(typeof token).toBe('string');
    expect(token.split('.')).toHaveLength(3); // JWT has 3 parts
  });

  it('should verify valid token', () => {
    const jwt = require('jsonwebtoken');
    const payload = { userId: 'test-id', email: 'test@example.com' };
    const secret = 'test-secret-key-min-32-characters-long';
    
    const token = jwt.sign(payload, secret, { expiresIn: '1h' });
    const decoded = jwt.verify(token, secret);
    
    expect(decoded).toBeDefined();
    expect((decoded as any).userId).toBe('test-id');
    expect((decoded as any).email).toBe('test@example.com');
  });

  it('should reject expired token', () => {
    const jwt = require('jsonwebtoken');
    const payload = { userId: 'test-id' };
    const secret = 'test-secret-key-min-32-characters-long';
    
    const token = jwt.sign(payload, secret, { expiresIn: '0s' });
    
    expect(() => {
      jwt.verify(token, secret);
    }).toThrow();
  });
});
