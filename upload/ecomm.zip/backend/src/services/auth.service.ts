import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import db from '../config/database';
import env from '../config/env';

interface RegisterDto {
  email: string;
  password: string;
  name: string;
}

interface LoginDto {
  email: string;
  password: string;
}

interface AuthResponse {
  user: {
    id: string;
    email: string;
    name: string;
    role: string;
  };
  token: string;
  refreshToken: string;
}

export class AuthService {
  async register(data: RegisterDto): Promise<AuthResponse> {
    // Check if user exists
    const existing = await db`
      SELECT id FROM users WHERE email = ${data.email}
    `;

    if (existing.length > 0) {
      throw new Error('Email already registered');
    }

    // Hash password
    const passwordHash = await bcrypt.hash(data.password, 10);

    // Create user
    const user = await db`
      INSERT INTO users (email, password_hash, name, role)
      VALUES (${data.email}, ${passwordHash}, ${data.name}, 'customer')
      RETURNING id, email, name, role
    `;

    // Generate tokens
    const token = this.generateToken(user[0]);
    const refreshToken = this.generateRefreshToken(user[0].id);

    return {
      user: user[0],
      token,
      refreshToken,
    };
  }

  async login(data: LoginDto): Promise<AuthResponse> {
    // Find user
    const user = await db`
      SELECT id, email, name, role, password_hash, is_active 
      FROM users 
      WHERE email = ${data.email}
    `;

    if (user.length === 0) {
      throw new Error('Invalid credentials');
    }

    if (!user[0].is_active) {
      throw new Error('Account is deactivated');
    }

    // Verify password
    const isValid = await bcrypt.compare(data.password, user[0].password_hash);
    if (!isValid) {
      throw new Error('Invalid credentials');
    }

    // Generate tokens
    const token = this.generateToken(user[0]);
    const refreshToken = this.generateRefreshToken(user[0].id);

    return {
      user: {
        id: user[0].id,
        email: user[0].email,
        name: user[0].name,
        role: user[0].role,
      },
      token,
      refreshToken,
    };
  }

  async refreshToken(refreshToken: string): Promise<{ token: string; refreshToken: string }> {
    try {
      const decoded = jwt.verify(refreshToken, env.JWT_REFRESH_SECRET) as { userId: string };
      
      const user = await db`
        SELECT id, email, name, role FROM users WHERE id = ${decoded.userId} AND is_active = true
      `;

      if (user.length === 0) {
        throw new Error('User not found');
      }

      const token = this.generateToken(user[0]);
      const newRefreshToken = this.generateRefreshToken(user[0].id);

      return { token, refreshToken: newRefreshToken };
    } catch (error) {
      throw new Error('Invalid refresh token');
    }
  }

  private generateToken(user: any): string {
    return jwt.sign(
      {
        userId: user.id,
        email: user.email,
        role: user.role,
      },
      env.JWT_SECRET,
      { expiresIn: env.JWT_EXPIRES_IN }
    );
  }

  private generateRefreshToken(userId: string): string {
    return jwt.sign(
      { userId, tokenType: 'refresh' },
      env.JWT_REFRESH_SECRET,
      { expiresIn: env.JWT_REFRESH_EXPIRES_IN }
    );
  }
}

export default new AuthService();
