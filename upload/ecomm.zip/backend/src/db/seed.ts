import db from '../config/database';
import bcrypt from 'bcryptjs';

export async function seed() {
  console.log('🌱 Starting database seeding...');

  try {
    // Create admin user
    const adminPassword = await bcrypt.hash('admin123', 10);
    await db`
      INSERT INTO users (email, password_hash, name, role, is_active, email_verified)
      VALUES ('admin@shopmitra.in', ${adminPassword}, 'Admin User', 'super_admin', true, true)
      ON CONFLICT (email) DO NOTHING
    `;

    // Create demo customer
    const customerPassword = await bcrypt.hash('demo123', 10);
    await db`
      INSERT INTO users (email, password_hash, name, role, is_active, email_verified)
      VALUES ('demo@shopmitra.in', ${customerPassword}, 'Demo Customer', 'customer', true, true)
      ON CONFLICT (email) DO NOTHING
    `;

    // Create categories
    const categories = [
      { name: 'Electronics', slug: 'electronics', sort_order: 1 },
      { name: 'Fashion', slug: 'fashion', sort_order: 2 },
      { name: 'Home & Living', slug: 'home-living', sort_order: 3 },
      { name: 'Beauty', slug: 'beauty', sort_order: 4 },
      { name: 'Sports', slug: 'sports', sort_order: 5 },
    ];

    for (const cat of categories) {
      await db`
        INSERT INTO categories (name, slug, sort_order)
        VALUES (${cat.name}, ${cat.slug}, ${cat.sort_order})
        ON CONFLICT (slug) DO NOTHING
      `;
    }

    // Get category IDs
    const electronics = await db`SELECT id FROM categories WHERE slug = 'electronics'`;
    const fashion = await db`SELECT id FROM categories WHERE slug = 'fashion'`;
    const homeLiving = await db`SELECT id FROM categories WHERE slug = 'home-living'`;
    const beauty = await db`SELECT id FROM categories WHERE slug = 'beauty'`;
    const sports = await db`SELECT id FROM categories WHERE slug = 'sports'`;

    // Create products
    const products = [
      {
        name: 'iPhone 15 Pro Max',
        slug: 'iphone-15-pro-max',
        description: 'The most advanced iPhone ever with A17 Pro chip, titanium design, and an incredible camera system.',
        short_description: 'A17 Pro chip, titanium design, 48MP camera',
        price: 134900,
        compare_price: 159900,
        images: ['https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800'],
        category_id: electronics[0]?.id,
        brand: 'Apple',
        sku: 'APL-IP15PM-256',
        stock: 45,
        rating: 4.8,
        review_count: 2847,
        is_featured: true,
        tags: ['bestseller', 'new'],
        specifications: JSON.stringify({ Display: '6.7" Super Retina XDR', Chip: 'A17 Pro', Storage: '256GB' }),
      },
      {
        name: 'MacBook Air M3',
        slug: 'macbook-air-m3',
        description: 'Supercharged by M3 chip. The remarkably thin MacBook Air with powerful performance.',
        short_description: 'M3 chip, 15.3" display, 18hr battery',
        price: 149900,
        compare_price: 169900,
        images: ['https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800'],
        category_id: electronics[0]?.id,
        brand: 'Apple',
        sku: 'APL-MBA-M3-512',
        stock: 30,
        rating: 4.9,
        review_count: 1523,
        is_featured: true,
        tags: ['bestseller', 'trending'],
        specifications: JSON.stringify({ Chip: 'Apple M3', Memory: '8GB', Storage: '512GB SSD' }),
      },
      {
        name: 'Sony WH-1000XM5',
        slug: 'sony-wh1000xm5',
        description: 'Industry-leading noise cancellation with Auto NC Optimizer. Up to 30 hours of battery life.',
        short_description: 'Best-in-class ANC, 30hr battery',
        price: 29990,
        compare_price: 34990,
        images: ['https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=800'],
        category_id: electronics[0]?.id,
        brand: 'Sony',
        sku: 'SNY-WH1000XM5',
        stock: 78,
        rating: 4.7,
        review_count: 3201,
        is_featured: true,
        tags: ['bestseller'],
        specifications: JSON.stringify({ Driver: '30mm', Battery: '30 hours', Weight: '250g' }),
      },
      {
        name: 'Premium Cotton T-Shirt',
        slug: 'premium-cotton-tee',
        description: 'Ultra-soft 100% organic cotton t-shirt with a relaxed fit.',
        short_description: '100% organic cotton, relaxed fit',
        price: 1499,
        compare_price: 2499,
        images: ['https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800'],
        category_id: fashion[0]?.id,
        brand: 'ShopMitra Essentials',
        sku: 'SVE-TEE-001',
        stock: 200,
        rating: 4.5,
        review_count: 892,
        is_featured: false,
        tags: ['sale', 'sustainable'],
        specifications: JSON.stringify({ Material: '100% Organic Cotton', Fit: 'Relaxed' }),
      },
      {
        name: 'Ergonomic Office Chair',
        slug: 'ergonomic-office-chair',
        description: 'Premium ergonomic office chair with adjustable lumbar support.',
        short_description: 'Adjustable lumbar, breathable mesh',
        price: 24999,
        compare_price: 34999,
        images: ['https://images.unsplash.com/photo-1580480055273-228ff5388ef8?w=800'],
        category_id: homeLiving[0]?.id,
        brand: 'ErgoMax',
        sku: 'ERM-CHR-PRO',
        stock: 25,
        rating: 4.6,
        review_count: 654,
        is_featured: true,
        tags: ['trending'],
        specifications: JSON.stringify({ Material: 'Mesh & Aluminum', Weight_Capacity: '150kg' }),
      },
    ];

    for (const product of products) {
      await db`
        INSERT INTO products (name, slug, description, short_description, price, compare_price, images, category_id, brand, sku, stock, rating, review_count, is_featured, tags, specifications)
        VALUES (${product.name}, ${product.slug}, ${product.description}, ${product.short_description}, ${product.price}, ${product.compare_price}, ${product.images}, ${product.category_id}, ${product.brand}, ${product.sku}, ${product.stock}, ${product.rating}, ${product.review_count}, ${product.is_featured}, ${product.tags}, ${product.specifications}::jsonb)
        ON CONFLICT (slug) DO NOTHING
      `;
    }

    // Create banners
    const banners = [
      {
        title: 'Summer Sale',
        subtitle: 'Up to 50% off on electronics',
        cta_text: 'Shop Now',
        cta_link: '/products?category=electronics',
        image_url: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=1200',
        background_color: 'from-indigo-600 to-purple-600',
        sort_order: 1,
      },
      {
        title: 'New Arrivals',
        subtitle: 'Discover the latest trends',
        cta_text: 'Explore',
        cta_link: '/products?category=fashion',
        image_url: '',
        background_color: 'from-emerald-600 to-teal-600',
        sort_order: 2,
      },
    ];

    for (const banner of banners) {
      await db`
        INSERT INTO banners (title, subtitle, cta_text, cta_link, image_url, background_color, sort_order)
        VALUES (${banner.title}, ${banner.subtitle}, ${banner.cta_text}, ${banner.cta_link}, ${banner.image_url}, ${banner.background_color}, ${banner.sort_order})
      `;
    }

    // Create coupons
    const coupons = [
      { code: 'SAVE10', discount_type: 'percentage', discount_value: 10, min_order_amount: 500 },
      { code: 'FIRST20', discount_type: 'percentage', discount_value: 20, min_order_amount: 1000 },
      { code: 'SHOP15', discount_type: 'percentage', discount_value: 15, min_order_amount: 750 },
    ];

    for (const coupon of coupons) {
      await db`
        INSERT INTO coupons (code, discount_type, discount_value, min_order_amount, is_active)
        VALUES (${coupon.code}, ${coupon.discount_type}, ${coupon.discount_value}, ${coupon.min_order_amount}, true)
        ON CONFLICT (code) DO NOTHING
      `;
    }

    console.log('✅ Database seeding completed successfully');
    console.log('\n📧 Demo Accounts:');
    console.log('   Admin: admin@shopmitra.in / admin123');
    console.log('   Customer: demo@shopmitra.in / demo123');
  } catch (error) {
    console.error('❌ Seeding failed:', error);
    throw error;
  }
}

// Run seed if this file is executed directly
if (require.main === module) {
  seed()
    .then(() => process.exit(0))
    .catch(() => process.exit(1));
}
