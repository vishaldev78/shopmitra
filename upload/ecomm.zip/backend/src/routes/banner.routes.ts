import { Router } from 'express';
const router = Router();
router.get('/', (req, res) => res.json({ message: 'Banners endpoint - TODO' }));
export default router;
