import { Router } from 'express';
const router = Router();
router.post('/dodo', (req, res) => res.json({ message: 'Webhook endpoint - TODO' }));
export default router;
