import { Router } from 'express';
import db from '../config/database';
import { authenticate, authorize, AuthRequest } from '../middleware/auth';
import { asyncHandler } from '../middleware/errorHandler';
import cache, { CACHE_KEYS } from '../config/redis';

const router = Router();

// GET /api/products - Get all products with filters
router.get('/', asyncHandler(async (req, res) => {
  const { page = '1', limit = '20', category, search, brand, sort = 'newest', minPrice, maxPrice } = req.query;
  
  const pageNum = parseInt(page as string);
  const limitNum = parseInt(limit as string);
  const offset = (pageNum - 1) * limitNum;

  let orderBy = 'created_at DESC';
  if (sort === 'price_asc') orderBy = 'price ASC';
  if (sort === 'price_desc') orderBy = 'price DESC';
  if (sort === 'rating') orderBy = 'rating DESC';
  if (sort === 'popular') orderBy = 'review_count DESC';

  const products = await db`
    SELECT p.*, c.name as category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.is_active = true
    ${category ? db`AND p.category_id IN (SELECT id FROM categories WHERE slug = ${category})` : db``}
    ${search ? db`AND (p.name ILIKE ${'%' + search + '%'} OR p.description ILIKE ${'%' + search + '%'})` : db``}
    ${brand ? db`AND p.brand = ${brand}` : db``}
    ${minPrice ? db`AND p.price >= ${minPrice}` : db``}
    ${maxPrice ? db`AND p.price <= ${maxPrice}` : db``}
    ORDER BY ${db.unsafe(orderBy)}
    LIMIT ${limitNum} OFFSET ${offset}
  `;

  const totalResult = await db`SELECT COUNT(*) as count FROM products WHERE is_active = true`;
  const total = parseInt(totalResult[0].count);

  res.json({
    products,
    total,
    page: pageNum,
    limit: limitNum,
    totalPages: Math.ceil(total / limitNum),
  });
}));

// GET /api/products/featured - Get featured products
router.get('/featured', asyncHandler(async (req, res) => {
  const cached = await cache.get(CACHE_KEYS.PRODUCTS_FEATURED);
  if (cached) return res.json(cached);

  const products = await db`
    SELECT * FROM products WHERE is_featured = true AND is_active = true
    ORDER BY review_count DESC LIMIT 8
  `;

  await cache.set(CACHE_KEYS.PRODUCTS_FEATURED, products, 3600);
  res.json(products);
}));

// GET /api/products/:slug - Get single product
router.get('/:slug', asyncHandler(async (req, res) => {
  const { slug } = req.params;
  
  const product = await db`
    SELECT p.*, c.name as category_name
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    WHERE p.slug = ${slug}
  `;

  if (product.length === 0) {
    return res.status(404).json({ error: 'Product not found' });
  }

  const variants = await db`
    SELECT * FROM product_variants WHERE product_id = ${product[0].id}
  `;

  res.json({ ...product[0], variants });
}));

// POST /api/products - Create product (Admin only)
router.post('/', authenticate, authorize('admin', 'super_admin'), asyncHandler(async (req: AuthRequest, res) => {
  const { name, slug, description, price, compare_price, images, category_id, brand, sku, stock, is_featured, tags, specifications } = req.body;

  const product = await db`
    INSERT INTO products (name, slug, description, price, compare_price, images, category_id, brand, sku, stock, is_featured, tags, specifications)
    VALUES (${name}, ${slug || name.toLowerCase().replace(/\s+/g, '-')}, ${description}, ${price}, ${compare_price || null}, ${images || []}, ${category_id || null}, ${brand}, ${sku}, ${stock || 0}, ${is_featured || false}, ${tags || []}, ${JSON.stringify(specifications || {})}::jsonb)
    RETURNING *
  `;

  // Invalidate cache
  await cache.delPattern('products:*');

  res.status(201).json(product[0]);
}));

// PUT /api/products/:id - Update product (Admin only)
router.put('/:id', authenticate, authorize('admin', 'super_admin'), asyncHandler(async (req: AuthRequest, res) => {
  const { id } = req.params;
  const updates = req.body;

  const product = await db`
    UPDATE products SET ${db(updates)} WHERE id = ${id} RETURNING *
  `;

  if (product.length === 0) {
    return res.status(404).json({ error: 'Product not found' });
  }

  // Invalidate cache
  await cache.delPattern('products:*');

  res.json(product[0]);
}));

// DELETE /api/products/:id - Delete product (Admin only)
router.delete('/:id', authenticate, authorize('admin', 'super_admin'), asyncHandler(async (req: AuthRequest, res) => {
  const { id } = req.params;

  // Check if product has orders
  const orderCheck = await db`SELECT COUNT(*) as count FROM order_items WHERE product_id = ${id}`;
  
  if (parseInt(orderCheck[0].count) > 0) {
    // Soft delete
    await db`UPDATE products SET is_active = false WHERE id = ${id}`;
  } else {
    await db`DELETE FROM products WHERE id = ${id}`;
  }

  // Invalidate cache
  await cache.delPattern('products:*');

  res.status(204).send();
}));

export default router;
