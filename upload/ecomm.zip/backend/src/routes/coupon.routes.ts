import { Router } from 'express';
const router = Router();
router.get('/', (req, res) => res.json({ message: 'Coupons endpoint - TODO' }));
export default router;
