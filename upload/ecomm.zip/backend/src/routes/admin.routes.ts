import { Router } from 'express';
import { authenticate, authorize } from '../middleware/auth';
const router = Router();

// All admin routes require authentication and admin role
router.use(authenticate, authorize('admin', 'super_admin'));

router.get('/dashboard', (req, res) => res.json({ message: 'Admin dashboard - TODO' }));
router.get('/orders', (req, res) => res.json({ message: 'Admin orders - TODO' }));
router.get('/customers', (req, res) => res.json({ message: 'Admin customers - TODO' }));

export default router;
