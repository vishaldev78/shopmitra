import { neon, neonConfig } from '@neondatabase/serverless';
import env from '../config/env';

// Configure Neon for optimal performance
neonConfig.fetchConnectionCache = true;

export const db = neon(env.DATABASE_URL);

// Test database connection
export async function testConnection(): Promise<boolean> {
  try {
    const result = await db`SELECT 1 as test`;
    console.log('✅ Database connected successfully');
    return true;
  } catch (error) {
    console.error('❌ Database connection failed:', error);
    return false;
  }
}

// Helper for transactions
export async function transaction<T>(
  callback: (sql: typeof db) => Promise<T>
): Promise<T> {
  // Note: Neon serverless doesn't support traditional transactions
  // For critical operations, use application-level consistency
  return callback(db);
}

export default db;
