import { Redis } from '@upstash/redis';
import env from '../config/env';

let redis: Redis | null = null;

export function getRedis(): Redis | null {
  if (!env.REDIS_URL || !env.REDIS_TOKEN) {
    console.warn('⚠️  Redis not configured - caching disabled');
    return null;
  }

  if (!redis) {
    redis = new Redis({
      url: env.REDIS_URL,
      token: env.REDIS_TOKEN,
    });
    console.log('✅ Redis connected successfully');
  }

  return redis;
}

// Cache helper functions
export const cache = {
  async get<T>(key: string): Promise<T | null> {
    const client = getRedis();
    if (!client) return null;
    
    try {
      const data = await client.get<T>(key);
      return data;
    } catch (error) {
      console.error('Cache get error:', error);
      return null;
    }
  },

  async set<T>(key: string, value: T, ttlSeconds?: number): Promise<void> {
    const client = getRedis();
    if (!client) return;
    
    try {
      if (ttlSeconds) {
        await client.set(key, value, { ex: ttlSeconds });
      } else {
        await client.set(key, value);
      }
    } catch (error) {
      console.error('Cache set error:', error);
    }
  },

  async del(key: string): Promise<void> {
    const client = getRedis();
    if (!client) return;
    
    try {
      await client.del(key);
    } catch (error) {
      console.error('Cache delete error:', error);
    }
  },

  async delPattern(pattern: string): Promise<void> {
    const client = getRedis();
    if (!client) return;
    
    try {
      const keys = await client.keys(pattern);
      if (keys.length > 0) {
        await client.del(...keys);
      }
    } catch (error) {
      console.error('Cache delete pattern error:', error);
    }
  },
};

// Cache keys
export const CACHE_KEYS = {
  PRODUCTS: 'products:',
  PRODUCTS_FEATURED: 'products:featured',
  PRODUCTS_LIST: 'products:list',
  CATEGORIES: 'categories',
  BANNERS: 'banners',
  USER: 'user:',
  CART: 'cart:',
};

export default cache;
