// API Client - Calls REAL backend APIs
const API_URL = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

export async function apiCall(endpoint: string, options: RequestInit = {}) {
  const response = await fetch(`${API_URL}${endpoint}`, {
    ...options,
    credentials: 'include', // Send cookies
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || 'API call failed');
  }

  return data;
}

// Auth API
export const authAPI = {
  login: (email: string, password: string) =>
    apiCall('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    }),

  register: (email: string, password: string, name: string) =>
    apiCall('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, password, name }),
    }),

  logout: () =>
    apiCall('/api/auth/logout', { method: 'POST' }),

  getUser: () =>
    apiCall('/api/user'),
};

// Products API
export const productsAPI = {
  getAll: (params?: { category?: string; search?: string; sort?: string }) => {
    const searchParams = new URLSearchParams();
    if (params?.category) searchParams.set('category', params.category);
    if (params?.search) searchParams.set('search', params.search);
    if (params?.sort) searchParams.set('sort', params.sort);
    
    const query = searchParams.toString();
    return apiCall(`/api/products${query ? '?' + query : ''}`);
  },

  getBySlug: (slug: string) =>
    apiCall(`/api/products/${slug}`),
};

// Orders API
export const ordersAPI = {
  create: (data: {
    items: Array<{ product_id: string; quantity: number }>;
    shipping_address: any;
    payment_method: string;
    coupon_code?: string;
  }) =>
    apiCall('/api/orders', {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  getMyOrders: () =>
    apiCall('/api/orders'),
};
