// Redis Caching Service - Using Upstash Redis
// In production, use Upstash, Redis Labs, or AWS ElastiCache

import { Redis } from '@upstash/redis';

// Redis client initialization
let redisClient: Redis | null = null;

function getRedisClient(): Redis | null {
  if (!process.env.UPSTASH_REDIS_REST_URL || !process.env.UPSTASH_REDIS_REST_TOKEN) {
    console.warn('⚠️ Redis not configured - caching disabled');
    return null;
  }

  if (!redisClient) {
    redisClient = new Redis({
      url: process.env.UPSTASH_REDIS_REST_URL,
      token: process.env.UPSTASH_REDIS_REST_TOKEN,
    });
    console.log('✅ Redis connected successfully');
  }

  return redisClient;
}

// Cache operations
export const cache = {
  // Get cached data
  async get<T>(key: string): Promise<T | null> {
    try {
      const client = getRedisClient();
      if (!client) return null;

      const data = await client.get<T>(key);
      return data;
    } catch (error) {
      console.error('Cache get error:', error);
      return null;
    }
  },

  // Set cache with TTL
  async set<T>(key: string, value: T, ttlSeconds: number = 3600): Promise<void> {
    try {
      const client = getRedisClient();
      if (!client) return;

      await client.set(key, value, { ex: ttlSeconds });
    } catch (error) {
      console.error('Cache set error:', error);
    }
  },

  // Delete cache
  async del(key: string): Promise<void> {
    try {
      const client = getRedisClient();
      if (!client) return;

      await client.del(key);
    } catch (error) {
      console.error('Cache delete error:', error);
    }
  },

  // Delete multiple keys by pattern
  async delPattern(pattern: string): Promise<void> {
    try {
      const client = getRedisClient();
      if (!client) return;

      const keys = await client.keys(pattern);
      if (keys.length > 0) {
        await client.del(...keys);
      }
    } catch (error) {
      console.error('Cache delete pattern error:', error);
    }
  },

  // Check if key exists
  async exists(key: string): Promise<boolean> {
    try {
      const client = getRedisClient();
      if (!client) return false;

      const result = await client.exists(key);
      return result > 0;
    } catch (error) {
      console.error('Cache exists error:', error);
      return false;
    }
  },

  // Increment counter
  async incr(key: string): Promise<number> {
    try {
      const client = getRedisClient();
      if (!client) return 0;

      return await client.incr(key);
    } catch (error) {
      console.error('Cache incr error:', error);
      return 0;
    }
  },

  // Set with expiration timestamp
  async setex<T>(key: string, seconds: number, value: T): Promise<void> {
    try {
      const client = getRedisClient();
      if (!client) return;

      await client.set(key, value, { ex: seconds });
    } catch (error) {
      console.error('Cache setex error:', error);
    }
  },
};

// Cache key patterns
export const CACHE_KEYS = {
  // Products
  PRODUCTS_LIST: 'products:list',
  PRODUCTS_FEATURED: 'products:featured',
  PRODUCT_DETAIL: (slug: string) => `products:detail:${slug}`,
  PRODUCTS_BY_CATEGORY: (categoryId: string) => `products:category:${categoryId}`,
  
  // Categories
  CATEGORIES_ALL: 'categories:all',
  CATEGORIES_TREE: 'categories:tree',
  
  // Banners
  BANNERS_ACTIVE: 'banners:active',
  
  // User
  USER_PROFILE: (userId: string) => `user:${userId}:profile`,
  USER_CART: (userId: string) => `user:${userId}:cart`,
  USER_WISHLIST: (userId: string) => `user:${userId}:wishlist`,
  
  // Orders
  USER_ORDERS: (userId: string) => `user:${userId}:orders`,
  ORDER_DETAIL: (orderId: string) => `order:${orderId}`,
  
  // Analytics
  DASHBOARD_STATS: 'analytics:dashboard',
  TOP_PRODUCTS: 'analytics:top_products',
  
  // Rate limiting
  RATE_LIMIT: (ip: string, endpoint: string) => `ratelimit:${ip}:${endpoint}`,
};

// Cache TTL constants (in seconds)
export const CACHE_TTL = {
  SHORT: 300, // 5 minutes
  MEDIUM: 3600, // 1 hour
  LONG: 86400, // 24 hours
  VERY_LONG: 604800, // 7 days
};

// Cache wrapper for API routes
export async function withCache<T>(
  key: string,
  fetcher: () => Promise<T>,
  ttl: number = CACHE_TTL.MEDIUM
): Promise<T> {
  // Try to get from cache first
  const cached = await cache.get<T>(key);
  if (cached !== null) {
    console.log(`✅ Cache hit: ${key}`);
    return cached;
  }

  // If not in cache, fetch data
  console.log(`❌ Cache miss: ${key}`);
  const data = await fetcher();

  // Store in cache
  await cache.set(key, data, ttl);

  return data;
}

// Invalidate related caches
export async function invalidateProductCache(productId?: string, slug?: string) {
  await cache.del(CACHE_KEYS.PRODUCTS_LIST);
  await cache.del(CACHE_KEYS.PRODUCTS_FEATURED);
  
  if (slug) {
    await cache.del(CACHE_KEYS.PRODUCT_DETAIL(slug));
  }
  
  await cache.delPattern('products:category:*');
}

export async function invalidateOrderCache(userId: string) {
  await cache.del(CACHE_KEYS.USER_ORDERS(userId));
  await cache.del(CACHE_KEYS.DASHBOARD_STATS);
}

export async function invalidateUserCache(userId: string) {
  await cache.del(CACHE_KEYS.USER_PROFILE(userId));
  await cache.del(CACHE_KEYS.USER_CART(userId));
  await cache.del(CACHE_KEYS.USER_WISHLIST(userId));
}

// Rate limiting with Redis
export async function checkRateLimit(
  ip: string,
  endpoint: string,
  maxRequests: number = 100,
  windowSeconds: number = 900 // 15 minutes
): Promise<{ allowed: boolean; remaining: number }> {
  const key = CACHE_KEYS.RATE_LIMIT(ip, endpoint);
  
  const current = await cache.incr(key);
  
  if (current === 1) {
    // First request, set expiration
    await cache.setex(key, windowSeconds, current);
  }
  
  const remaining = Math.max(0, maxRequests - current);
  
  return {
    allowed: current <= maxRequests,
    remaining,
  };
}

export default cache;
