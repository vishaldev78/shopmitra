import { neon } from '@neondatabase/serverless';

// Server-side database connection - SECURE!
const sql = neon(process.env.DATABASE_URL!);

export async function testConnection() {
  try {
    const result = await sql`SELECT 1 as test`;
    console.log('✅ Database connected successfully');
    return true;
  } catch (error) {
    console.error('❌ Database connection failed:', error);
    return false;
  }
}

export default sql;
