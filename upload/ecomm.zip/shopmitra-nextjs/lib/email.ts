// Email Service - Real email notifications
// In production, use a service like SendGrid, AWS SES, or Mailgun

export interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

// Email templates
export const emailTemplates = {
  orderConfirmation: (orderNumber: string, total: number, customerName: string) => ({
    subject: `Order Confirmation - ${orderNumber}`,
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            .order-details { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }
            .button { display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎉 Order Confirmed!</h1>
              <p>Thank you for shopping with ShopMitra</p>
            </div>
            <div class="content">
              <h2>Hi ${customerName},</h2>
              <p>Your order has been successfully placed and is being processed.</p>
              
              <div class="order-details">
                <h3>Order Details</h3>
                <p><strong>Order Number:</strong> ${orderNumber}</p>
                <p><strong>Total Amount:</strong> ₹${total.toLocaleString('en-IN')}</p>
                <p><strong>Order Date:</strong> ${new Date().toLocaleDateString('en-IN')}</p>
              </div>
              
              <p>We'll notify you when your order ships. You can track your order status anytime from your account.</p>
              
              <a href="${process.env.NEXT_PUBLIC_APP_URL}/account/orders" class="button">View Order Details</a>
              
              <p>Thank you for choosing ShopMitra!</p>
              <p>Best regards,<br>The ShopMitra Team</p>
            </div>
            <div class="footer">
              <p>© 2024 ShopMitra. All rights reserved.</p>
              <p>This is an automated email. Please do not reply.</p>
            </div>
          </div>
        </body>
      </html>
    `,
    text: `Order Confirmation - ${orderNumber}\n\nHi ${customerName},\n\nYour order has been successfully placed.\n\nOrder Number: ${orderNumber}\nTotal Amount: ₹${total.toLocaleString('en-IN')}\n\nThank you for shopping with ShopMitra!`,
  }),

  orderShipped: (orderNumber: string, trackingNumber: string) => ({
    subject: `Your Order ${orderNumber} has been Shipped!`,
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            .tracking-box { background: white; padding: 20px; border-radius: 8px; margin: 20px 0; text-align: center; }
            .button { display: inline-block; padding: 12px 30px; background: #11998e; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>📦 Your Order is on the Way!</h1>
            </div>
            <div class="content">
              <h2>Great News!</h2>
              <p>Your order <strong>${orderNumber}</strong> has been shipped and is on its way to you.</p>
              
              <div class="tracking-box">
                <h3>Tracking Information</h3>
                <p><strong>Tracking Number:</strong> ${trackingNumber}</p>
                <p>Estimated Delivery: 3-5 business days</p>
              </div>
              
              <a href="${process.env.NEXT_PUBLIC_APP_URL}/track-order?number=${orderNumber}" class="button">Track Your Order</a>
              
              <p>Thank you for shopping with ShopMitra!</p>
            </div>
          </div>
        </body>
      </html>
    `,
    text: `Your order ${orderNumber} has been shipped!\n\nTracking Number: ${trackingNumber}\nEstimated Delivery: 3-5 business days`,
  }),

  passwordReset: (resetToken: string, userName: string) => ({
    subject: 'Password Reset Request - ShopMitra',
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            .button { display: inline-block; padding: 12px 30px; background: #f5576c; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            .warning { background: #fff3cd; padding: 15px; border-left: 4px solid #ffc107; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🔐 Password Reset Request</h1>
            </div>
            <div class="content">
              <h2>Hi ${userName},</h2>
              <p>We received a request to reset your password. Click the button below to create a new password:</p>
              
              <a href="${process.env.NEXT_PUBLIC_APP_URL}/reset-password?token=${resetToken}" class="button">Reset Password</a>
              
              <div class="warning">
                <strong>⚠️ Security Notice:</strong><br>
                This link will expire in 1 hour. If you didn't request this, please ignore this email and your password will remain unchanged.
              </div>
              
              <p>If you're having trouble clicking the button, copy and paste this URL into your browser:</p>
              <p style="word-break: break-all; font-size: 12px; color: #666;">${process.env.NEXT_PUBLIC_APP_URL}/reset-password?token=${resetToken}</p>
            </div>
          </div>
        </body>
      </html>
    `,
    text: `Password Reset Request\n\nHi ${userName},\n\nClick the link below to reset your password:\n${process.env.NEXT_PUBLIC_APP_URL}/reset-password?token=${resetToken}\n\nThis link will expire in 1 hour.`,
  }),

  welcomeEmail: (userName: string) => ({
    subject: 'Welcome to ShopMitra! 🎉',
    html: `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            .features { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; }
            .feature { background: white; padding: 15px; border-radius: 8px; text-align: center; }
            .button { display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>🎉 Welcome to ShopMitra!</h1>
              <p>Your Shopping Friend</p>
            </div>
            <div class="content">
              <h2>Hi ${userName},</h2>
              <p>Thank you for joining ShopMitra! We're excited to have you as part of our community.</p>
              
              <div class="features">
                <div class="feature">
                  <h3>🛍️</h3>
                  <p>Premium Products</p>
                </div>
                <div class="feature">
                  <h3>💰</h3>
                  <p>Best Prices</p>
                </div>
                <div class="feature">
                  <h3>🚚</h3>
                  <p>Fast Delivery</p>
                </div>
                <div class="feature">
                  <h3>🔒</h3>
                  <p>Secure Payments</p>
                </div>
              </div>
              
              <p>Start exploring our collection and enjoy exclusive member benefits!</p>
              
              <a href="${process.env.NEXT_PUBLIC_APP_URL}/products" class="button">Start Shopping</a>
              
              <p>Happy Shopping!<br>The ShopMitra Team</p>
            </div>
          </div>
        </body>
      </html>
    `,
    text: `Welcome to ShopMitra!\n\nHi ${userName},\n\nThank you for joining ShopMitra! Start exploring our collection of premium products at the best prices.\n\nHappy Shopping!`,
  }),
};

// Send email function
export async function sendEmail(options: EmailOptions): Promise<{ success: boolean; error?: string }> {
  try {
    // In development, just log the email
    if (process.env.NODE_ENV === 'development') {
      console.log('📧 Email sent (development mode):');
      console.log('  To:', options.to);
      console.log('  Subject:', options.subject);
      console.log('  Body:', options.text || options.html.substring(0, 200) + '...');
      return { success: true };
    }

    // In production, use a real email service
    // Example with SendGrid:
    // const sgMail = require('@sendgrid/mail');
    // sgMail.setApiKey(process.env.SENDGRID_API_KEY);
    // await sgMail.send({
    //   to: options.to,
    //   from: process.env.EMAIL_FROM,
    //   subject: options.subject,
    //   html: options.html,
    //   text: options.text,
    // });

    // For now, just log in production too (replace with real service)
    console.log('📧 Email sent (production):');
    console.log('  To:', options.to);
    console.log('  Subject:', options.subject);
    
    return { success: true };
  } catch (error: any) {
    console.error('❌ Email send failed:', error);
    return { success: false, error: error.message };
  }
}

// Helper functions for common emails
export async function sendOrderConfirmation(email: string, orderNumber: string, total: number, customerName: string) {
  const template = emailTemplates.orderConfirmation(orderNumber, total, customerName);
  return sendEmail({ to: email, ...template });
}

export async function sendOrderShipped(email: string, orderNumber: string, trackingNumber: string) {
  const template = emailTemplates.orderShipped(orderNumber, trackingNumber);
  return sendEmail({ to: email, ...template });
}

export async function sendPasswordReset(email: string, resetToken: string, userName: string) {
  const template = emailTemplates.passwordReset(resestToken, userName);
  return sendEmail({ to: email, ...template });
}

export async function sendWelcomeEmail(email: string, userName: string) {
  const template = emailTemplates.welcomeEmail(userName);
  return sendEmail({ to: email, ...template });
}
