// File Upload Service - Cloudinary integration
// In production, use Cloudinary, AWS S3, or similar service

export interface UploadResult {
  success: boolean;
  url?: string;
  publicId?: string;
  error?: string;
}

// Cloudinary configuration (in production)
const CLOUDINARY_CONFIG = {
  cloudName: process.env.CLOUDINARY_CLOUD_NAME,
  apiKey: process.env.CLOUDINARY_API_KEY,
  apiSecret: process.env.CLOUDINARY_API_SECRET,
};

// File validation
export function validateFile(file: File): { valid: boolean; error?: string } {
  const maxSize = 5 * 1024 * 1024; // 5MB
  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

  if (file.size > maxSize) {
    return { valid: false, error: 'File size must be less than 5MB' };
  }

  if (!allowedTypes.includes(file.type)) {
    return { valid: false, error: 'Only JPEG, PNG, WebP, and GIF files are allowed' };
  }

  return { valid: true };
}

// Upload file to Cloudinary (production)
export async function uploadToCloudinary(file: File, folder: string = 'products'): Promise<UploadResult> {
  try {
    // Validate file
    const validation = validateFile(file);
    if (!validation.valid) {
      return { success: false, error: validation.error };
    }

    // In development, create a local URL
    if (process.env.NODE_ENV === 'development' || !CLOUDINARY_CONFIG.cloudName) {
      const localUrl = URL.createObjectURL(file);
      return {
        success: true,
        url: localUrl,
        publicId: `dev_${Date.now()}`,
      };
    }

    // In production, upload to Cloudinary
    const formData = new FormData();
    formData.append('file', file);
    formData.append('upload_preset', 'shopmitra_uploads');
    formData.append('folder', folder);

    const response = await fetch(
      `https://api.cloudinary.com/v1_1/${CLOUDINARY_CONFIG.cloudName}/image/upload`,
      {
        method: 'POST',
        body: formData,
      }
    );

    if (!response.ok) {
      throw new Error('Upload failed');
    }

    const data = await response.json();

    return {
      success: true,
      url: data.secure_url,
      publicId: data.public_id,
    };
  } catch (error: any) {
    console.error('❌ Upload failed:', error);
    return { success: false, error: error.message || 'Upload failed' };
  }
}

// Delete file from Cloudinary
export async function deleteFromCloudinary(publicId: string): Promise<{ success: boolean; error?: string }> {
  try {
    if (process.env.NODE_ENV === 'development' || !CLOUDINARY_CONFIG.cloudName) {
      console.log('🗑️ File deleted (development mode):', publicId);
      return { success: true };
    }

    // In production, delete from Cloudinary
    // Implementation would go here
    console.log('🗑️ File deleted:', publicId);
    return { success: true };
  } catch (error: any) {
    console.error('❌ Delete failed:', error);
    return { success: false, error: error.message };
  }
}

// Upload multiple files
export async function uploadMultipleFiles(files: FileList, folder: string = 'products'): Promise<UploadResult[]> {
  const results: UploadResult[] = [];

  for (let i = 0; i < files.length; i++) {
    const result = await uploadToCloudinary(files[i], folder);
    results.push(result);
  }

  return results;
}

// Get optimized image URL
export function getOptimizedImageUrl(url: string, options: {
  width?: number;
  height?: number;
  quality?: number;
  format?: 'auto' | 'webp' | 'jpg' | 'png';
} = {}): string {
  if (!url || url.startsWith('blob:')) return url;

  const { width, height, quality = 'auto', format = 'auto' } = options;
  
  // For Cloudinary URLs, add transformation parameters
  if (url.includes('cloudinary.com')) {
    const transformations = [];
    if (width) transformations.push(`w_${width}`);
    if (height) transformations.push(`h_${height}`);
    if (quality !== 'auto') transformations.push(`q_${quality}`);
    if (format !== 'auto') transformations.push(`f_${format}`);
    
    if (transformations.length > 0) {
      return url.replace('/upload/', `/upload/${transformations.join(',')}/`);
    }
  }

  return url;
}

// File upload component helper
export function getFileUploadProps(accept: string = 'image/*', multiple: boolean = false) {
  return {
    accept,
    multiple,
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files;
      if (files) {
        console.log('Files selected:', files.length);
      }
    },
  };
}
