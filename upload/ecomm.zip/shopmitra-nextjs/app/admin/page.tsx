import { getSession } from '@/lib/auth';
import { redirect } from 'next/navigation';
import sql from '@/lib/db';
import Link from 'next/link';

export default async function AdminDashboard() {
  // Check authentication and admin role
  const session = await getSession();
  if (!session || (session.role !== 'admin' && session.role !== 'super_admin')) {
    redirect('/login');
  }

  // Fetch dashboard stats
  const stats = await sql`
    SELECT 
      (SELECT COUNT(*) FROM users WHERE role = 'customer') as total_customers,
      (SELECT COUNT(*) FROM products WHERE is_active = true) as total_products,
      (SELECT COUNT(*) FROM orders) as total_orders,
      (SELECT COALESCE(SUM(total), 0) FROM orders WHERE payment_status = 'paid') as total_revenue,
      (SELECT COUNT(*) FROM orders WHERE status = 'pending') as pending_orders,
      (SELECT COUNT(*) FROM products WHERE stock < 20 AND is_active = true) as low_stock_products
  `;

  // Fetch recent orders
  const recentOrders = await sql`
    SELECT o.*, u.name as customer_name, u.email as customer_email
    FROM orders o
    LEFT JOIN users u ON o.user_id = u.id
    ORDER BY o.created_at DESC
    LIMIT 10
  `;

  // Fetch low stock products
  const lowStockProducts = await sql`
    SELECT id, name, stock, price, images
    FROM products
    WHERE stock < 20 AND is_active = true
    ORDER BY stock ASC
    LIMIT 10
  `;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="font-cursive text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            ShopMitra
          </Link>
          <div className="flex items-center gap-4">
            <span className="text-sm text-gray-600">Welcome, {session.name || 'Admin'}</span>
            <Link href="/admin/products" className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
              Manage Products
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-navy-900 mb-8">Admin Dashboard</h1>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">Total Revenue</span>
              <span className="text-2xl">💰</span>
            </div>
            <p className="text-3xl font-bold text-navy-900">
              ₹{Number(stats[0].total_revenue).toLocaleString('en-IN')}
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">Total Orders</span>
              <span className="text-2xl">📦</span>
            </div>
            <p className="text-3xl font-bold text-navy-900">{stats[0].total_orders}</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">Total Customers</span>
              <span className="text-2xl">👥</span>
            </div>
            <p className="text-3xl font-bold text-navy-900">{stats[0].total_customers}</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">Total Products</span>
              <span className="text-2xl">🛍️</span>
            </div>
            <p className="text-3xl font-bold text-navy-900">{stats[0].total_products}</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">Pending Orders</span>
              <span className="text-2xl">⏳</span>
            </div>
            <p className="text-3xl font-bold text-amber-600">{stats[0].pending_orders}</p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-500">Low Stock Products</span>
              <span className="text-2xl">⚠️</span>
            </div>
            <p className="text-3xl font-bold text-red-600">{stats[0].low_stock_products}</p>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Recent Orders */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-bold text-navy-900 mb-4">Recent Orders</h2>
            <div className="space-y-3">
              {recentOrders.map((order: any) => (
                <div key={order.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-navy-900">{order.order_number}</p>
                    <p className="text-sm text-gray-500">{order.customer_name || order.guest_email}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-navy-900">₹{Number(order.total).toLocaleString('en-IN')}</p>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      order.status === 'delivered' ? 'bg-green-100 text-green-700' :
                      order.status === 'shipped' ? 'bg-blue-100 text-blue-700' :
                      'bg-amber-100 text-amber-700'
                    }`}>
                      {order.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Low Stock Alert */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-bold text-navy-900 mb-4">Low Stock Alert</h2>
            <div className="space-y-3">
              {lowStockProducts.map((product: any) => (
                <div key={product.id} className="flex items-center gap-3 p-3 bg-amber-50 rounded-lg">
                  <div className="w-12 h-12 bg-gray-200 rounded-lg flex items-center justify-center text-2xl">
                    {product.images?.[0]?.startsWith('http') ? (
                      <img src={product.images[0]} alt="" className="w-full h-full object-cover rounded-lg" />
                    ) : '📦'}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-navy-900">{product.name}</p>
                    <p className="text-sm text-amber-600">Only {product.stock} left in stock</p>
                  </div>
                  <p className="font-bold text-navy-900">₹{Number(product.price).toLocaleString('en-IN')}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
