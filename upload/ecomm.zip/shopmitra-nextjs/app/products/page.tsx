import Link from 'next/link';
import { productsAPI } from '@/lib/api';

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: { category?: string; search?: string; sort?: string };
}) {
  let products = [];
  try {
    const data = await productsAPI.getAll(searchParams);
    products = data.products || [];
  } catch (error) {
    console.error('Failed to fetch products:', error);
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="font-cursive text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            ShopMitra
          </Link>
          <nav className="flex items-center gap-6">
            <Link href="/products" className="text-indigo-600 font-medium">Products</Link>
            <Link href="/login" className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">Login</Link>
          </nav>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-navy-900 mb-6">All Products</h1>
        <p className="text-gray-500 mb-8">{products.length} products found</p>

        {products.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">No products found.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.map((product: any) => (
              <Link key={product.id} href={`/products/${product.slug}`} className="bg-white rounded-xl shadow-sm hover:shadow-md transition p-4">
                <div className="aspect-square bg-gray-100 rounded-lg mb-3 flex items-center justify-center text-6xl overflow-hidden">
                  {product.images?.[0]?.startsWith('http') ? (
                    <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover" />
                  ) : (
                    '📦'
                  )}
                </div>
                <h3 className="font-medium text-navy-900 line-clamp-2 mb-1">{product.name}</h3>
                <p className="text-xs text-gray-500 mb-2">{product.brand}</p>
                <div className="flex items-baseline gap-2">
                  <p className="text-lg font-bold text-navy-900">₹{Number(product.price).toLocaleString()}</p>
                  {product.compare_price && Number(product.compare_price) > Number(product.price) && (
                    <p className="text-sm text-gray-400 line-through">₹{Number(product.compare_price).toLocaleString()}</p>
                  )}
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
