import { NextRequest, NextResponse } from 'next/server';
import sql from '@/lib/db';
import { getSession } from '@/lib/auth';

// POST /api/orders - Create order (requires login)
export async function POST(request: NextRequest) {
  try {
    // 🔒 CHECK LOGIN - Server-side authentication
    const session = await getSession();
    if (!session) {
      return NextResponse.json(
        { error: 'Login required to place order' },
        { status: 401 }
      );
    }

    const { items, shipping_address, payment_method, coupon_code } = await request.json();

    // Validation
    if (!items || items.length === 0) {
      return NextResponse.json({ error: 'Cart is empty' }, { status: 400 });
    }

    if (!shipping_address) {
      return NextResponse.json({ error: 'Shipping address required' }, { status: 400 });
    }

    // Calculate totals server-side (SECURE - never trust client prices)
    let subtotal = 0;
    const orderItems = [];

    for (const item of items) {
      const product = await sql`SELECT * FROM products WHERE id = ${item.product_id}`;
      if (product.length === 0) {
        return NextResponse.json({ error: `Product not found: ${item.product_id}` }, { status: 400 });
      }

      if (product[0].stock < item.quantity) {
        return NextResponse.json({ error: `Insufficient stock for: ${product[0].name}` }, { status: 400 });
      }

      const unitPrice = Number(product[0].price);
      const totalPrice = unitPrice * item.quantity;
      subtotal += totalPrice;

      orderItems.push({
        product_id: item.product_id,
        product_name: product[0].name,
        product_image: product[0].images?.[0] || '',
        quantity: item.quantity,
        unit_price: unitPrice,
        total_price: totalPrice,
      });
    }

    // Apply coupon if provided
    let discount = 0;
    if (coupon_code) {
      const coupon = await sql`
        SELECT * FROM coupons WHERE code = ${coupon_code.toUpperCase()} AND is_active = true
      `;
      if (coupon.length > 0) {
        if (coupon[0].discount_type === 'percentage') {
          discount = Math.round(subtotal * Number(coupon[0].discount_value) / 100);
        } else {
          discount = Number(coupon[0].discount_value);
        }
      }
    }

    const shipping = subtotal > 999 ? 0 : 99;
    const tax = Math.round((subtotal - discount) * 0.18);
    const total = subtotal - discount + shipping + tax;

    // Generate order number
    const orderNumber = 'SM-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase();

    // Create order
    const order = await sql`
      INSERT INTO orders (order_number, user_id, subtotal, discount, shipping, tax, total, status, payment_status, payment_method, shipping_address)
      VALUES (${orderNumber}, ${session.userId}, ${subtotal}, ${discount}, ${shipping}, ${tax}, ${total}, 'pending', ${payment_method === 'cod' ? 'pending' : 'paid'}, ${payment_method}, ${JSON.stringify(shipping_address)}::jsonb)
      RETURNING *
    `;

    // Create order items
    for (const item of orderItems) {
      await sql`
        INSERT INTO order_items (order_id, product_id, product_name, product_image, quantity, unit_price, total_price)
        VALUES (${order[0].id}, ${item.product_id}, ${item.product_name}, ${item.product_image}, ${item.quantity}, ${item.unit_price}, ${item.total_price})
      `;

      // Decrement stock
      await sql`UPDATE products SET stock = stock - ${item.quantity} WHERE id = ${item.product_id}`;
    }

    return NextResponse.json({
      success: true,
      order: order[0],
      orderNumber,
    }, { status: 201 });

  } catch (error: any) {
    console.error('Order error:', error);
    return NextResponse.json({ error: 'Failed to create order' }, { status: 500 });
  }
}

// GET /api/orders - Get user orders (requires login)
export async function GET(request: NextRequest) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: 'Login required' }, { status: 401 });
    }

    const orders = await sql`
      SELECT * FROM orders WHERE user_id = ${session.userId} ORDER BY created_at DESC
    `;

    return NextResponse.json({ orders });
  } catch (error: any) {
    console.error('Orders error:', error);
    return NextResponse.json({ error: 'Failed to fetch orders' }, { status: 500 });
  }
}
