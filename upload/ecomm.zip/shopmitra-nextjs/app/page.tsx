import Link from 'next/link';
import { productsAPI } from '@/lib/api';

export default async function Home() {
  // ✅ REAL API CALL - Server-side data fetching
  let products = [];
  try {
    const data = await productsAPI.getAll();
    products = data.products || [];
  } catch (error) {
    console.error('Failed to fetch products:', error);
  }

  return (
    <main className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <span className="font-cursive text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              ShopMitra
            </span>
          </Link>
          <nav className="flex items-center gap-6">
            <Link href="/products" className="text-navy-700 hover:text-indigo-600">Products</Link>
            <Link href="/login" className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">Login</Link>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <section className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-5xl font-bold mb-4">Welcome to ShopMitra</h1>
          <p className="text-xl mb-8">Your Shopping Friend - Premium products at best prices</p>
          <Link href="/products" className="inline-block px-8 py-3 bg-white text-indigo-600 rounded-xl font-semibold hover:bg-gray-100">
            Shop Now
          </Link>
        </div>
      </section>

      {/* Products */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-navy-900 mb-8">Featured Products</h2>
        
        {products.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">No products found. Run database seed first.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {products.slice(0, 8).map((product: any) => (
              <Link key={product.id} href={`/products/${product.slug}`} className="bg-white rounded-xl shadow-sm hover:shadow-md transition p-4">
                <div className="aspect-square bg-gray-100 rounded-lg mb-3 flex items-center justify-center text-6xl">
                  {product.images?.[0]?.startsWith('http') ? (
                    <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover rounded-lg" />
                  ) : (
                    '📦'
                  )}
                </div>
                <h3 className="font-medium text-navy-900 line-clamp-2 mb-2">{product.name}</h3>
                <p className="text-xs text-gray-500 mb-2">{product.brand}</p>
                <p className="text-lg font-bold text-navy-900">₹{Number(product.price).toLocaleString()}</p>
              </Link>
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
